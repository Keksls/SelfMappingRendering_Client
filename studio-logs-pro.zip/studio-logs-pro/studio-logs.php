<?php
/**
 * Plugin Name: Studio Logs
 * Description: Admin UI to display render logs from wp_studio_logs with filtering, search, pagination and CSV export.
 * Version: 2.0
 * Author: Airbus Liverender
 */

if (!defined('ABSPATH')) exit;

// Load admin classes
require_once plugin_dir_path(__FILE__) . 'includes/class-studio-logs-admin.php';

// Ensure table exists on activation (safe if already there)
register_activation_hook(__FILE__, function () {
    global $wpdb;
    $table = $wpdb->prefix . "studio_logs";

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        created_at DATETIME NOT NULL,
        first_name VARCHAR(255) NULL,
        last_name VARCHAR(255) NULL,
        email VARCHAR(255) NULL,
        type VARCHAR(255) NULL,
        airline VARCHAR(255) NULL,
        aircraft VARCHAR(255) NULL,
        view VARCHAR(255) NULL,
        environment VARCHAR(255) NULL,
        resolution VARCHAR(255) NULL,
        mode VARCHAR(255) NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
});

add_action('wp_ajax_studio_logs_export', 'studio_logs_export_csv');

function studio_logs_export_csv() {
    require plugin_dir_path(__FILE__) . 'includes/export-csv.php';
    exit;
}