jQuery(document).ready(function ($) {

    $("#studio-export-csv").on("click", function () {

        const params = new URLSearchParams(window.location.search);

        params.set("action", "studio_logs_export");

        fetch(ajaxurl + "?" + params.toString(), {
            method: "GET",
            credentials: "same-origin"
        })
            .then(response => response.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement("a");

                const ts = new Date().toISOString().replace(/[:.]/g, "-");
                a.download = `studio_logs_${ts}.csv`;
                a.href = url;

                document.body.appendChild(a);
                a.click();
                a.remove();

                window.URL.revokeObjectURL(url);
            })
            .catch(err => {
                alert("CSV export failed: " + err);
                console.error(err);
            });
    });

});