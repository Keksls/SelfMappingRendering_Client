<?php
if (!defined('ABSPATH')) exit;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Studio_Logs_ListTable extends WP_List_Table {

    public function __construct() {
        parent::__construct([
            'singular' => 'studio_log',
            'plural'   => 'studio_logs',
            'ajax'     => false
        ]);
    }

    public function get_columns() {
        return [
            'created_at' => __('Date', 'studio-logs'),
            'first_name' => __('First Name', 'studio-logs'),
            'last_name'  => __('Last Name', 'studio-logs'),
            'email'      => __('Email', 'studio-logs'),
            'type'       => __('Type', 'studio-logs'),
            'airline'    => __('Airline', 'studio-logs'),
            'aircraft'   => __('Aircraft', 'studio-logs'),
            'view'       => __('View', 'studio-logs'),
            'environment'=> __('Environment', 'studio-logs'),
            'resolution' => __('Resolution', 'studio-logs'),
            'mode'       => __('Mode', 'studio-logs')
        ];
    }

    protected function get_sortable_columns() {
        return [
            'created_at' => ['created_at', true],
            'email'      => ['email', false],
            'type'       => ['type', false],
            'airline'    => ['airline', false],
            'aircraft'   => ['aircraft', false],
            'mode'       => ['mode', false],
        ];
    }

    public function no_items() {
        _e('No logs found.', 'studio-logs');
    }

    public function prepare_items() {
        global $wpdb;

        $table = $wpdb->prefix . 'studio_logs';

        $per_page = $this->get_items_per_page('studio_logs_per_page', 25);
        $current_page = $this->get_pagenum();

        $search = isset($_GET['s']) ? wp_unslash($_GET['s']) : '';

        $filter_type  = isset($_GET['filter_type']) ? sanitize_text_field(wp_unslash($_GET['filter_type'])) : '';
        $filter_mode  = isset($_GET['filter_mode']) ? sanitize_text_field(wp_unslash($_GET['filter_mode'])) : '';
        $filter_airline = isset($_GET['filter_airline']) ? sanitize_text_field(wp_unslash($_GET['filter_airline'])) : '';
        $filter_env   = isset($_GET['filter_environment']) ? sanitize_text_field(wp_unslash($_GET['filter_environment'])) : '';
        $filter_name = isset($_GET['filter_name']) ? sanitize_text_field(wp_unslash($_GET['filter_name'])) : '';

        $where = "WHERE 1=1";
        $params = [];

        if ($search !== '') {
            $like = '%' . $wpdb->esc_like($search) . '%';
            $where .= " AND (first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR type LIKE %s OR airline LIKE %s OR aircraft LIKE %s OR view LIKE %s OR environment LIKE %s OR resolution LIKE %s OR mode LIKE %s)";
            $params = array_merge($params, array_fill(0, 10, $like));
        }

        if ($filter_type !== '') {
            $where .= " AND type = %s";
            $params[] = $filter_type;
        }
        if ($filter_mode !== '') {
            $where .= " AND mode = %s";
            $params[] = $filter_mode;
        }
        if ($filter_airline !== '') {
            $where .= " AND airline = %s";
            $params[] = $filter_airline;
        }
        if ($filter_env !== '') {
            $where .= " AND environment = %s";
            $params[] = $filter_env;
        }
        if ($filter_name !== '') {
            $like = '%' . $wpdb->esc_like($filter_name) . '%';
            $where .= " AND (first_name LIKE %s OR last_name LIKE %s OR email LIKE %s)";
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        // Sorting
        $orderby = isset($_GET['orderby']) ? sanitize_key($_GET['orderby']) : 'created_at';
        $order   = isset($_GET['order']) ? strtoupper(sanitize_text_field($_GET['order'])) : 'DESC';
        if (!in_array($order, ['ASC','DESC'], true)) {
            $order = 'DESC';
        }

        $allowed_orderby = ['created_at','email','type','airline','aircraft','mode'];
        if (!in_array($orderby, $allowed_orderby, true)) {
            $orderby = 'created_at';
        }

        // Total items
        $count_sql = "SELECT COUNT(*) FROM $table $where";
        $total_items = $params ? $wpdb->get_var($wpdb->prepare($count_sql, $params)) : $wpdb->get_var($count_sql);

        // Fetch items
        $offset = ($current_page - 1) * $per_page;
        $data_sql = "SELECT * FROM $table $where ORDER BY $orderby $order LIMIT %d OFFSET %d";
        $params_with_limit = $params;
        $params_with_limit[] = $per_page;
        $params_with_limit[] = $offset;

        $this->items = $params_with_limit ? $wpdb->get_results($wpdb->prepare($data_sql, $params_with_limit), ARRAY_A)
                                          : $wpdb->get_results($wpdb->prepare($data_sql, $per_page, $offset), ARRAY_A);

        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = [$columns, $hidden, $sortable];

        $this->set_pagination_args([
            'total_items' => (int) $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);
    }

    public function column_default($item, $column_name) {
        switch ($column_name) {
            case 'created_at':
                // Format date nicely
                $ts = strtotime($item['created_at']);
                if ($ts) {
                    return esc_html( date_i18n('Y-m-d H:i', $ts) );
                }
                return esc_html($item['created_at']);
            default:
                return esc_html($item[$column_name]);
        }
    }

    protected function display_tablenav( $which ) {
        if ( $which === 'bottom' ) {
            return; // disable bottom nav completely
        }
        parent::display_tablenav( $which );
    }

    public function display() {
        // TOP navigation + header
        $this->display_tablenav('top');

        echo '<table class="wp-list-table ' . implode(' ', $this->get_table_classes()) . '">';
    
        // HEADER (only once)
        $this->print_column_headers();

        echo '<tbody id="the-list">';
        $this->display_rows_or_placeholder();
        echo '</tbody>';

        echo '</table>';
    }
}
