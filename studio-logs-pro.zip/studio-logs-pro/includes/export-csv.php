<?php
if (!defined('ABSPATH')) exit;

// NE RIEN AFFICHER D'AUTRE
while (ob_get_level()) ob_end_clean();

global $wpdb;
$table = $wpdb->prefix . 'studio_logs';

// R�cup�ration des filtres
$search       = $_GET['s']                ?? '';
$filter_type  = $_GET['filter_type']      ?? '';
$filter_mode  = $_GET['filter_mode']      ?? '';
$filter_air   = $_GET['filter_airline']   ?? '';
$filter_env   = $_GET['filter_environment'] ?? '';
$filter_name  = $_GET['filter_name']      ?? '';

$where  = "WHERE 1=1";
$params = [];

// Search plein texte
if ($search !== '') {
    $like = '%' . $wpdb->esc_like($search) . '%';
    $where .= " AND (
        first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR
        type LIKE %s OR airline LIKE %s OR aircraft LIKE %s OR
        view LIKE %s OR environment LIKE %s OR resolution LIKE %s OR
        mode LIKE %s
    )";
    $params = array_merge($params, array_fill(0, 10, $like));
}

if ($filter_name !== '') {
    $like = '%' . $wpdb->esc_like($filter_name) . '%';
    $where .= " AND (first_name LIKE %s OR last_name LIKE %s OR email LIKE %s)";
    array_push($params, $like, $like, $like);
}

if ($filter_type !== '') {
    $where .= " AND type = %s";
    $params[] = $filter_type;
}
if ($filter_mode !== '') {
    $where .= " AND mode = %s";
    $params[] = $filter_mode;
}
if ($filter_air !== '') {
    $where .= " AND airline = %s";
    $params[] = $filter_air;
}
if ($filter_env !== '') {
    $where .= " AND environment = %s";
    $params[] = $filter_env;
}

$sql = "SELECT * FROM $table $where ORDER BY created_at DESC";

$rows = $params ?
    $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) :
    $wpdb->get_results($sql, ARRAY_A);

header("Content-Type: text/csv; charset=utf-8");

$output = fopen('php://output', 'w');

fputcsv($output, [
    'Date','First Name','Last Name','Email','Type','Airline',
    'Aircraft','View','Environment','Resolution','Mode'
]);

foreach ($rows as $row) {
    fputcsv($output, [
        $row['created_at'],
        $row['first_name'],
        $row['last_name'],
        $row['email'],
        $row['type'],
        $row['airline'],
        $row['aircraft'],
        $row['view'],
        $row['environment'],
        $row['resolution'],
        $row['mode']
    ]);
}

fclose($output);
exit;