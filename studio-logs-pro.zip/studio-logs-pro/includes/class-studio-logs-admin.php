<?php
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'class-studio-logs-listtable.php';

class Studio_Logs_Admin {

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'admin_css']);
        add_filter('set-screen-option', [$this, 'set_screen_option'], 10, 3);
    }

    public function admin_css($hook) {
        if ($hook !== 'toplevel_page_studio-logs') return;
        wp_enqueue_style('studio-logs-admin', plugin_dir_url(__FILE__) . '../assets/admin.css', [], '2.0');
        wp_enqueue_script(
            'studio-logs-js',
            plugin_dir_url(__FILE__) . '../assets/admin.js',
            ['jquery'],
            '2.0',
            true
        );
    }

    public function register_menu() {
        $hook = add_menu_page(
            'Studio Logs',
            'Studio Logs',
            'manage_options',
            'studio-logs',
            [$this, 'render_admin_page'],
            'dashicons-analytics',
            30
        );

        add_action("load-$hook", [$this, 'screen_options']);
    }

    public function screen_options() {
        $args = [
            'label'   => __('Logs per page', 'studio-logs'),
            'default' => 25,
            'option'  => 'studio_logs_per_page'
        ];
        add_screen_option('per_page', $args);
    }

    public function set_screen_option($status, $option, $value) {
        if ($option === 'studio_logs_per_page') {
            return (int) $value;
        }
        return $status;
    }

    private function get_distinct_values($column) {
        global $wpdb;
        $table = $wpdb->prefix . 'studio_logs';
        $column = sanitize_key($column);
        $results = $wpdb->get_col("SELECT DISTINCT $column FROM $table WHERE $column IS NOT NULL AND $column <> '' ORDER BY $column ASC");
        return $results ?: [];
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        // Handle CSV export BEFORE any output
        if (isset($_GET['export']) && $_GET['export'] === 'csv') {
            require_once plugin_dir_path(__FILE__) . 'export-csv.php';
            exit;
        }

        $table = new Studio_Logs_ListTable();
        $table->prepare_items();

        // Prepare filters
        $current_type  = isset($_GET['filter_type']) ? sanitize_text_field(wp_unslash($_GET['filter_type'])) : '';
        $current_mode  = isset($_GET['filter_mode']) ? sanitize_text_field(wp_unslash($_GET['filter_mode'])) : '';
        $current_airline = isset($_GET['filter_airline']) ? sanitize_text_field(wp_unslash($_GET['filter_airline'])) : '';
        $current_env   = isset($_GET['filter_environment']) ? sanitize_text_field(wp_unslash($_GET['filter_environment'])) : '';
        $current_name = isset($_GET['filter_name']) ? sanitize_text_field(wp_unslash($_GET['filter_name'])) : '';

        $types      = $this->get_distinct_values('type');
        $modes      = $this->get_distinct_values('mode');
        $airlines   = $this->get_distinct_values('airline');
        $environments = $this->get_distinct_values('environment');

        echo '<div class="wrap">';
        echo '<h1 class="wp-heading-inline">Studio Logs</h1>';
        echo '<button type="button" id="studio-export-csv" class="page-title-action">Export CSV</button>';
        echo '<hr class="wp-header-end">';

        echo '<form method="get" class="studio-logs-filters">';
        echo '<input type="hidden" name="page" value="studio-logs"/>';

        // Filters row
        echo '<div class="studio-logs-filters-row">';

        // Name filter
        echo '<div class="studio-logs-filter">';
        echo '<label for="filter_name">Name / Email</label>';
        echo '<input type="text" name="filter_name" id="filter_name" value="' . esc_attr($current_name) . '">';
        echo '</div>';

        // Type filter
        echo '<div class="studio-logs-filter">';
        echo '<label for="filter_type">Type</label>';
        echo '<select name="filter_type" id="filter_type">';
        echo '<option value="">All</option>';
        foreach ($types as $t) {
            printf('<option value="%1$s"%2$s>%1$s</option>',
                esc_attr($t),
                selected($current_type, $t, false)
            );
        }
        echo '</select></div>';

        // Airline filter
        echo '<div class="studio-logs-filter">';
        echo '<label for="filter_airline">Airline</label>';
        echo '<select name="filter_airline" id="filter_airline">';
        echo '<option value="">All</option>';
        foreach ($airlines as $a) {
            printf('<option value="%1$s"%2$s>%1$s</option>',
                esc_attr($a),
                selected($current_airline, $a, false)
            );
        }
        echo '</select></div>';

        // Environment filter
        echo '<div class="studio-logs-filter">';
        echo '<label for="filter_environment">Environment</label>';
        echo '<select name="filter_environment" id="filter_environment">';
        echo '<option value="">All</option>';
        foreach ($environments as $e) {
            printf('<option value="%1$s"%2$s>%1$s</option>',
                esc_attr($e),
                selected($current_env, $e, false)
            );
        }
        echo '</select></div>';

        // Mode filter
        echo '<div class="studio-logs-filter">';
        echo '<label for="filter_mode">Mode</label>';
        echo '<select name="filter_mode" id="filter_mode">';
        echo '<option value="">All</option>';
        foreach ($modes as $m) {
            printf('<option value="%1$s"%2$s>%1$s</option>',
                esc_attr($m),
                selected($current_mode, $m, false)
            );
        }
        echo '</select></div>';

        echo '<div class="studio-logs-filter studio-logs-filter-actions">';
        submit_button(__('Filter'), 'secondary', 'filter_action', false);
        echo '</div>';

        echo '</div>'; // filters row

        // Search + table
        $table->search_box('Search Logs', 'studio-logs-search');
        $table->display();
        echo '</form>';

        echo '</div>';
    }
}

new Studio_Logs_Admin();
